#include<stdlib.h>
#include<stdio.h>
#include<stdbool.h>
#include<math.h>
#include<string.h>





typedef struct Cacherow {
	int valid;
	int tag;
	int blocksize;
} Cacherow;

typedef struct CacheSet
{
	Cacherow* rows;
	int * rowUsage;
} CacheSet;

typedef struct CacheCounter {
	int memoryRead;
	int memoryWrite;
	int cacheHit;
	int cacheMiss;
}CacheCounter;

void PrintCounter(CacheCounter c);
void PrintCache(CacheSet* cache, int cacheSize, int rowsPerSet);
unsigned long parseTraceLine(char* line, char* operationType, unsigned long* memoryAddress);
unsigned long Cutlong( unsigned long number, int startRightbit, int length);
CacheCounter StartCache(CacheSet* cache, int cachesetSize, int rowsPerSet, FILE* fileHandle, int blocksize, char* cachePolicy, int prefectSize);
int CacheHitCheck(CacheSet cacheset, int rowsPerSet, int tagnumber, int offsetnumber);
void LoadFromMemory(CacheSet* cache, int rowPerSet, unsigned long int memoryAddress, int setbits, int blockbits, char* cachepolicy);
int FindReplaceRowIndex(CacheSet cacheset, int rowsPerSet, char* cachePolicy);
void UpdateRowUsage(CacheSet cacheset, int rowsPerSet, char* cachePolicy, int replacedRowIndex);

int main(int argc, char** argv) {
	if (argc < 7)
	{
		printf("error");
		exit(0);

	}

	int cacheSize;
	int blockSize;
	//int tagSize;
	char cachePolicy[100];
	char assoc[100];
	int n;
	int prefetchSize;
	char traceFile[100];
	//int setSize;

	//int miss;
	//int hit;
	//CacheSet** cache;
	//int setNumber;
	//int tagNumber;




	if (sscanf(argv[1], "%d", &cacheSize) != 1 || floor(log2(cacheSize)) != ceil(log2(cacheSize))) {
		printf("error\n");
		exit(0);
	}
	if (sscanf(argv[2], "%d", &blockSize) != 1 || floor(log2(blockSize)) != ceil(log2(blockSize))) {
		printf("error");
		exit(0);
	}
	if (sscanf(argv[3], "%s", cachePolicy) == EOF || (strcmp(cachePolicy, "fifo") != 0 && strcmp(cachePolicy, "lru") != 0))
	{
		printf("error\n");
		exit(0);
	}
	if (sscanf(argv[4], "%s", assoc) == EOF)
	{
		printf("error\n");
		exit(0);
	}
	else
	{
		if (strcmp(assoc, "direct") != 0)
		{
			if (strcmp(assoc, "assoc") != 0)
			{
				if (sscanf(assoc, "assoc:%d", &n) != 1 || floor(log2(n)) != ceil(log2(n))) {
					printf("error");
					exit(0);
				}
				n = n;
			}
			else
			{
				strcpy(assoc, "assoc");
				n = (int)(cacheSize / blockSize);
			}


		}
		else
		{
			n = 1;
			strcpy(assoc, "direct");
		}

	}
	if (sscanf(argv[5], "%d", &prefetchSize) == 0)
	{
		printf("error\n");
		exit(0);
	}
	if (sscanf(argv[6], "%s", traceFile) == EOF)
	{
		printf("error\n");
		exit(0);
	}
	//printf("%d\t%d\t%s\t%s\t%d\t%s", &cacheSize, &blockSize, &cachePolicy, &assoc, &prefetchSize, &traceFile);
	int numberOfCacherow = cacheSize / blockSize;

	 int numberOfSet = numberOfCacherow / n;

	// CacheSet* set;
	//for (int i = 0; i < numberOfSet; i++)
	//{
	//	set = (CacheSet*)malloc(sizeof(numberOfSet));
	//}
	
	/*for (int j = 0; j < numberOfCacherow; j++)
	{
		Cacherow* cache = malloc(sizeof(numberOfCacherow));
	}*/

	//CacheSet* cache = malloc(sizeof(CacheSet) * numberOfSet);
	//for (int a = 0; a < numberOfSet; a++)
	//{
	//	cache[a].rows = malloc(sizeof(Cacherow) * n);
	//	cache[a].rowUsage = malloc(sizeof(sizeof(int) * n));

	//	for (int j = 0; j < n; j++)
	//	{
	//		cache[a].rows[j].valid = 0;
	//		cache[a].rows[j].blocksize = blockSize;
	//		cache[a].rowUsage[j] = 0;
	//	}
	//}

	FILE* traceHandle = fopen(traceFile, "r");
	if (traceHandle == NULL)
	{
		printf("error\n");
		exit(0);
	}

	

	CacheSet* nonPrefetchSet = malloc(sizeof(CacheSet) * numberOfSet);
	for (int a = 0; a < numberOfSet; a++)
	{
		nonPrefetchSet[a].rows = malloc(sizeof(Cacherow) * n);
		nonPrefetchSet[a].rowUsage = malloc(sizeof(int) * n);

		for (int j = 0; j < n; j++)
		{
			nonPrefetchSet[a].rows[j].valid = 0;
			nonPrefetchSet[a].rows[j].blocksize = blockSize;
			nonPrefetchSet[a].rowUsage[j] = 0;
		}
	}

	CacheSet* prefetchSet= malloc(sizeof(CacheSet) * numberOfSet);
	for (int a = 0; a < numberOfSet; a++)
	{
		prefetchSet[a].rows = malloc(sizeof(Cacherow) * n);
		prefetchSet[a].rowUsage = malloc(sizeof(int) * n);

		for (int j = 0; j < n; j++)
		{
			prefetchSet[a].rows[j].valid = 0;
			prefetchSet[a].rows[j].blocksize = blockSize;
			prefetchSet[a].rowUsage[j] = 0;
		}
	}

	//for (int i = 0; i < numberOfSet; i++)
	//{
	//	fgets(traceFile, 255, traceHandle);
	//}
	FILE * withoutPrefetchTraceHandler= fopen(traceFile, "r");
	FILE * withPrefetchTraceHandler = fopen(traceFile, "r");
       
	printf("no-prefetch\n");
	CacheCounter cwe = StartCache(nonPrefetchSet, numberOfSet, n,withoutPrefetchTraceHandler, blockSize, cachePolicy, 0);
	PrintCounter(cwe);
	printf("with-prefetch\n");
	CacheCounter cw= StartCache(prefetchSet, numberOfSet, n,withPrefetchTraceHandler, blockSize, cachePolicy, prefetchSize);
	PrintCounter(cw);

	for (int b = 0; b < numberOfSet; b++)
	{
		free(nonPrefetchSet[b].rows);
		free(nonPrefetchSet[b].rowUsage);
		free(prefetchSet[b].rows);
		free(prefetchSet[b].rowUsage);

	}
	free(nonPrefetchSet);
	free(prefetchSet);

	return 0;
}




void PrintCounter(CacheCounter c) {
	printf("Memory reads: %d\n", c.memoryRead);
	printf("Memory writes: %d\n", c.memoryWrite);
	printf("Cache hits: %d\n", c.cacheHit);
	printf("Cache misses: %d\n", c.cacheMiss);
}

void PrintCache(CacheSet* cache, int cacheSize, int rowsPerSet) {
	for (int i = 0; i < cacheSize; i++)
	{
		printf("# Set %d\n", i);
		for (int j = 0; j < rowsPerSet; j++)
		{
			printf(" %d %d - %d\n", cache[i].rows[j].valid, cache[i].rows[j].tag, cache[i].rowUsage[j]);
		}
	}
}
    

unsigned long parseTraceLine(char* line, char* operationType, unsigned long* memoryAddress) {
	char address[100];
	int parseResult = sscanf(line, "%s 0x%s", operationType, address);
	if (parseResult!=2)
	{
		printf("error");
		exit(0);
	}
	*memoryAddress = strtol(address, NULL, 16);
	return *memoryAddress;
}


unsigned long Cutlong(unsigned long number, int startRightbit, int length) {
	unsigned long temp = number;
	unsigned long mask = 0;
	for (int i = 0; i < length; i++)
	{
		mask = (mask << 1) + 1;
	}
	return (temp >> startRightbit)& mask;
}

CacheCounter StartCache(CacheSet* cache, int cachesetSize, int rowsPerSet, FILE* fileHandle, int blocksize, char* cachePolicy, int prefectSize) {
	char line[255];
	char operationType[100];
	unsigned long memoryaddress = 0;
	int blockbit = log2(blocksize);
	int setbit = log2(cachesetSize);
	int offsetnumber = 0;
	int setnumber = 0;
	int tagnumber = 0;
	int rowIndex = 0;
	CacheCounter counter = { 0,0,0,0 };
	
	while (fgets(line, 255, fileHandle) && strstr(line, "#eof") == NULL) {
		parseTraceLine(line, operationType, &memoryaddress);
		offsetnumber = Cutlong(memoryaddress, 0, blockbit);
		setnumber = Cutlong(memoryaddress, blockbit, setbit);
		tagnumber = Cutlong(memoryaddress, blockbit+setbit, 48-blockbit-setbit);
		rowIndex = CacheHitCheck(cache[setnumber], rowsPerSet, tagnumber, offsetnumber);
		if (strcmp(operationType,"W")==0)
		{
			counter.memoryWrite += 1;
			counter.cacheHit += 1;
			continue;
		}

		else if (strcmp(operationType, "R") == 0) {
		if (rowIndex!=-1)
		{
			counter.cacheHit += 1;
			if (strcmp(cachePolicy,"lru")==0)
			{
				cache[setnumber].rowUsage[rowIndex]+=1;
			}
			continue;
		}
		else
		{
			
			counter.cacheMiss+=1;
			counter.memoryRead+=1;
			LoadFromMemory(cache, rowsPerSet,memoryaddress,setbit,blockbit,cachePolicy);
			for (int i = 1; i <= prefectSize; i++)
			{
				unsigned long memoryToPrefetch = memoryaddress + i * blocksize;
				int fn = Cutlong(memoryToPrefetch, 0, blockbit);
				int sn = Cutlong(memoryToPrefetch, blockbit, setbit);
				int tn = Cutlong(memoryToPrefetch, blockbit + setbit, 48 - blockbit - setbit);
				if (CacheHitCheck(cache[sn],rowsPerSet,tn,fn)==-1)
				{
					counter.memoryRead += 1;
					LoadFromMemory(cache, rowsPerSet, memoryToPrefetch, setbit, blockbit, cachePolicy);
					}
				}
			}

		}
		
	}
    return counter;
}

int CacheHitCheck(CacheSet cacheset, int rowsPerSet, int tagnumber, int offsetnumber) {
	for (int i = 0; i < rowsPerSet; i++)
	{
		if (cacheset.rows[i].blocksize<=offsetnumber)
		{
			continue;
		}
		if (cacheset.rows[i].valid==1&&cacheset.rows[i].tag==tagnumber)
		{
			return i;
		}
	}
	return -1;
}

void LoadFromMemory(CacheSet* cache, int rowPerSet, unsigned long memoryAddress, int setbits, int blockbits, char* cachepolicy) {

	int setNumber = Cutlong(memoryAddress, blockbits, setbits);
	int tagNumber = Cutlong(memoryAddress, blockbits + setbits, 64);
	int replaceMenRowIndex = FindReplaceRowIndex(cache[setNumber], rowPerSet, cachepolicy);
	cache[setNumber].rows[replaceMenRowIndex].valid = 1;
	cache[setNumber].rows[replaceMenRowIndex].tag = tagNumber;
	UpdateRowUsage(cache[setNumber], rowPerSet, cachepolicy, replaceMenRowIndex);
	return;
}

int FindReplaceRowIndex(CacheSet cacheset, int rowsPerSet, char* cachePolicy) {
	if (strcmp(cachePolicy, "fifo") == 0) {
		int oldsetUsage = 0;
		int oldestIndex = 0;
		for (int i = 0; i < rowsPerSet; i++)
		{
			if (cacheset.rows[i].valid==0)
			{
				return i;
			}
			if (cacheset.rowUsage[i]>oldsetUsage)
			{
				oldestIndex = i;
				oldsetUsage = cacheset.rowUsage[i];
			}
		}
		return oldestIndex;
	}
	else if (strcmp(cachePolicy,"lru")==0)
	{
		int usageCount=2147473647;
		int usageMinIndex=0;
		for (int i = 0; i < rowsPerSet; i++)
		{
			if (cacheset.rows[i].valid==0)
			{
				return i;
			}
			if (cacheset.rowUsage[i]< usageCount)
			{
				usageMinIndex = i;
				usageCount = cacheset.rowUsage[i];
			}
		}
		return usageMinIndex;
	}
	else
	{
		printf("error\n");
		exit(0);
	}
	return -1;
}

void UpdateRowUsage(CacheSet cacheset, int rowsPerSet, char* cachePolicy, int replacedRowIndex) {
	if (strcmp(cachePolicy, "fifo") == 0)
	{
		for (int i = 0; i < rowsPerSet; i++)
		{
			cacheset.rowUsage[i] += 1;
		}
		cacheset.rowUsage[replacedRowIndex] = 0;
		return;
	}
	else if (strcmp(cachePolicy, "lru") == 0) {
		cacheset.rowUsage[replacedRowIndex] = 0;
		return;
	}
	else
	{
		printf("error\n");
		exit(0);
	}
}



