#include<stdio.h>
#include<stdlib.h>
#include<stdbool.h>


void printTable(int tableLength, char dukuTable[tableLength][tableLength]);
int findNext(int tableLength, char dukuTable[tableLength][tableLength], int* rowPosition, int* colPosition);
int isValidrow(int tableLength, char dukuTable[tableLength][tableLength], int row, int col, char insertChar);
int isValidcol(int tableLength, char dukuTable[tableLength][tableLength], int row, int col, char insertChar);
int isValidbox(int tableLength, char dukuTable[tableLength][tableLength], int row, int col, char insertChar);
int solveDoku(int tableLength, char dukuTable[tableLength][tableLength], char possibleChar[tableLength]);

int main(int argc, char** argv) {
	if (argc<2)
	{
		printf("error,use valid file");
		exit(0);

	}
	
	FILE* fp = fopen(argv[1], "r");
	if (fp == NULL) {
		printf("No file here.\n");
		exit(0);
	}

	char line[255];
	char possibleChar[16] = "0123456789ABCDEF";
	char hexaduk[16][16];
	//int lineIndex = 0;
	int rowIndex = 0;
	int colIndex = 0;
	for(int lineIndex= 0;lineIndex  < 255; lineIndex++)
	{
		line[lineIndex] = '\n';
	}

	while (fgets(line,255,fp))
	{
		//int i = 0;
		for (int i = 0; i < 255; i++)
		{
			if (line[i]=='\n')
			{
				break;
			}
			else if (line[i]=='\t')
			{
				continue;
			}
			else
			{
				hexaduk[rowIndex][colIndex] = line[i];
				colIndex++;
			}
		}
		rowIndex++;
		colIndex=0;
	}
	
	int row, col;
	findNext(16, hexaduk, &row, &col);
	//	printf("%d %d\n", row, col);
	/*isValidrow(16,hexaduk,rowIndex,colIndex,possibleChar);
	printf("%d %d\n", row, col);
	isValidcol(16,hexaduk,rowIndex,colIndex,possibleChar);
	isValidbox(16,hexaduk,rowIndex,colIndex,possibleChar);*/
	solveDoku(16,hexaduk,possibleChar); 
	//	printTable(16, hexaduk);
	 if (findNext(16, hexaduk, &row, &col))
	{
		printf("no-solution\n");
	}
	else
	{
		for (row = 0; row < 16; row++)
		{
			for (col = 0; col < 16; col++) {
			  if (!(isValidrow(16,hexaduk,row,col,hexaduk[row][col])&& 
					isValidcol(16, hexaduk, row, col, hexaduk[row][col])&&
				isValidbox(16, hexaduk, row, col,hexaduk[row][col])))
				{
						printf("no-solution\n");
						exit(0);
				}
			}
		}
		printTable(16, hexaduk);
	      }
	 exit(0);
}

void printTable(int tableLength, char dukuTable[tableLength][tableLength]) {
	//int row = 0;
	//int col = 0;
	for (int row = 0; row < tableLength; row++)
	{
		for (int col = 0; col < tableLength; col++)
		{
			printf("%c\t", dukuTable[row][col]);
		}
	       	printf("\n");
	}
	return;
}

int findNext(int tableLength, char dukuTable[tableLength][tableLength], int* rowPosition, int* colPosition) {
	for (int row = 0; row < tableLength; row++)
	{
		for (int col = 0; col < tableLength; col++)
		{
			if (dukuTable[row][col]=='-')
			{
				* rowPosition = row;
				* colPosition = col;
				return 1;
			}
		}
	}
	return 0;
}

int isValidcol(int tableLength, char dukuTable[tableLength][tableLength], int row, int col, char insertChar) {
	//int tempRow = 0;
	char currentChar;
	for (int tempRow = 0; tempRow < tableLength; tempRow++)
	{
		currentChar = dukuTable[tempRow][col];
		if (currentChar=='-'||tempRow==row)
		{
			continue;
		}

		if (currentChar==insertChar)
		{
			return 0;
		}
	}
	return 1;
}

int isValidrow(int tableLength, char dukuTable[tableLength][tableLength], int row, int col, char insertChar) {
	//int tempRow = 0;
	char currentChar;
	for (int tempCol = 0; tempCol < tableLength; tempCol++)
	{
		currentChar = dukuTable[row][tempCol];
		if (currentChar == '-'||tempCol==col)
		{
			continue;
		}
		if (currentChar == insertChar)
		{
			return 0;
		}
	}
	return 1;
}
int isValidbox(int tableLength, char dukuTable[tableLength][tableLength], int row, int col, char insertChar) {
	//int tempRow = 0;
	char currentChar;
	int boxLen = 4;
	for (int tempRow = ((int)row/boxLen)*boxLen; tempRow < ((int)row / boxLen) * boxLen+boxLen; tempRow++)
	{
		for (int tempCol = ((int)col/ boxLen) * boxLen; tempCol< ((int)col / boxLen) * boxLen + boxLen; tempCol++)
		{
				currentChar = dukuTable[tempRow][tempCol];
				if (currentChar == '-'||(tempCol==col&&tempRow==row))
				{
					continue;
				}
				if (currentChar == insertChar)
				{
					return 0;
				}
		}
			
	}
	return 1;
}

int solveDoku(int tableLength, char dukuTable[tableLength][tableLength], char possibleChar[tableLength]) {
	int row, col;
	int charIndex;
	if (!findNext(tableLength,dukuTable,&row,&col))
	{
		return 1;
	}
	for (charIndex = 0;  charIndex < tableLength; charIndex++)
	{
		if (isValidrow(tableLength,dukuTable,row,col,possibleChar[charIndex])&& isValidcol(tableLength, dukuTable, row, col, possibleChar[charIndex])
		    && isValidbox(tableLength, dukuTable, row, col, possibleChar[charIndex])){
		
			dukuTable[row][col] =possibleChar[charIndex];
			if (solveDoku(tableLength,dukuTable,possibleChar))
			{
				return 1;
			}
			dukuTable[row][col]='-';
		}
		else
		{
			continue;
		}
	}
	return 0;
}

