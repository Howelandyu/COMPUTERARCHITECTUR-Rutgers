#include<stdio.h>
#include<stdlib.h>
#include<string.h>

void printResult(double** data, int rowNum, int colsNum);
void readTrain(char* trainFilePath, int* K, int* N, double*** trainX, double*** trainY);
void readTest(char* trainFilePath, int* K, int* N, double*** testX);
double** matrixDot(double*** dst, double** src1, double** src2, int src1Row, int src1Cols, int src2Row, int src2Cols);
double** matrixTranspose(double*** dst, double** src, int srcRows, int srcCols);
double** matrixInverse(double*** dst, double** src, int srcRows, int srcCols);
double* divideRow(double* row, double divisor, int rowCols);
double* susubtractNRowb(double* row, double* substractorMulRow, double multipler, int rowCols);
double** addCols(double*** dst,double** src, int srcRow,int srcCols);

int main(int argc, char* argv[]) {
	if (argc<3)
	{
		printf( "No file");
		return 0;

	}

	int trainN, trainK;
	int testN;

	double** trainX;
	double** trainY;
	double** testX;
	readTrain(argv[1], &trainK, &trainN, &trainX, &trainY);
	readTest(argv[2], &trainK, &testN, &testX);

	double** finalX;
	addCols(&finalX,trainX,trainN,trainK);

       	double** transX;
	matrixTranspose(&transX, finalX, trainN, trainK+1);

	double** DottransX;
        matrixDot(&DottransX, transX, finalX,  trainK+1,trainN , trainN, trainK+1);

       	double** InversX;
	matrixInverse(&InversX, DottransX, trainK+1,trainK+1);

       	double** DottranXtwo;
	matrixDot(&DottranXtwo, InversX, transX, trainK+1, trainK+1, trainK+1, trainN);

       	double** finalW;
	matrixDot(&finalW,DottranXtwo,trainY,trainK+1, trainN,trainN, 1);

	double** finaltestX;
	addCols(&finaltestX,testX,testN,trainK);
	
	double** finalResult;
	matrixDot(&finalResult,finaltestX,finalW,testN,trainK+1,trainK+1,1);

	printResult(finalResult,testN,1);
	return 0;
}
void printResult(double** data, int rows, int cols) {
	for (int row = 0; row < rows; row++)
	{
		for (int col = 0; col < cols; col++) {
			printf("%0.0f\n", data[row][col]);
		}
	}
	return;
}

void readTrain(char* trainFilePath, int* K,int* N, double*** trainX, double*** trainY) {
	FILE* trainFileHandle = fopen(trainFilePath, "r");
	char line[1000];
	for (int i = 0; i < 1000; i++)
	{
		line[i] = '\0';

	}

	if (fgets(line,1000,trainFileHandle))
	{
		*K=atoi(line);
	}

	if (fgets(line,1000,trainFileHandle))
	{
		*N = atoi(line);
	}

	*trainX = malloc(*N * sizeof(double*));
	*trainY = malloc(*N * sizeof(double*));
	for (int i = 0; i < *N; i++)
	{
		(*trainX)[i] = malloc(*N * sizeof(double*));
		(*trainY)[i] = malloc(*N * sizeof(double*));
	}
	char* token;
	const char delim[] = ",";
	int attributeIndex = 0;

	for (int rowIndex = 0; rowIndex <*N; rowIndex++)
	{
		fgets(line, 1000, trainFileHandle);
		token = strtok(line, delim);
		while (token!=NULL)
		{
			if (attributeIndex<*K)
			{
				(*trainX)[rowIndex][attributeIndex] = atof(token);
			}
			else
			{
				(*trainY)[rowIndex][0] = atof(token);
			}
			attributeIndex++;
			token = strtok(NULL, delim);
		}
		attributeIndex = 0;
	}
	fclose(trainFileHandle);
}

void readTest(char* trainFilePath, int* K, int* N, double*** testX) {
	FILE* trainFileHandle = fopen(trainFilePath, "r");
	char line[1000];
	for (int i = 0; i < 1000; i++)
	{
		line[i] = '\0';

	}

	if (fgets(line, 1000, trainFileHandle))
	{
		*N = atoi(line);
	}

	*testX = malloc(*N * sizeof(double*));
	for (int i = 0; i < *N; i++)
	{
		(*testX)[i] = malloc(*K * sizeof(double*));
	}
	char* token;
	const char delim[] = ",";
	int attributeIndex = 0;
	for (int rowIndex = 0; rowIndex < *N; rowIndex++)
	{
		fgets(line, 1000, trainFileHandle);
		token = strtok(line, delim);
		while (token != NULL)
		{
			if (attributeIndex < *K)
			{
				(*testX)[rowIndex][attributeIndex] = atof(token);
			}
			attributeIndex++;
			token = strtok(NULL, delim);
		}
		attributeIndex = 0;
	}
	fclose(trainFileHandle);
}

double** matrixDot(double*** dst, double** src1, double** src2, int src1Row, int src1Cols, int src2Row, int src2Cols) {
	if (src1Cols!=src2Row)
	{
		printf("matrix size error");
		exit(1);
	}

	*dst = malloc(src1Row * sizeof(double*));
	for (int i = 0; i < src1Row; i++)
	{
		(*dst)[i] = malloc(src2Cols * sizeof(double*));
	}
	for (int i = 0; i < src1Row; i++)
	{
		for (int j = 0; j < src2Cols; j++)
		{
			(*dst)[i][j] = 0;
		}
	}
	double tempResult = 0;
	for (int dstI = 0; dstI < src1Row; dstI++)
	{
		for (int dstJ = 0; dstJ < src2Cols; dstJ++)
		{
			for (int matrixL = 0; matrixL < src1Cols; matrixL++)
			{
				tempResult += src1[dstI][matrixL] * src2[matrixL][dstJ];
			}
			(*dst)[dstI][dstJ] = tempResult;
			tempResult = 0;
		}
	}
	return *dst;
}

double** matrixTranspose(double*** dst, double** src, int srcRows, int srcCols) {
	*dst = malloc(srcCols * sizeof(double*));
	for (int i = 0; i < srcCols; i++)
	{
	  (*dst)[i] = malloc(srcRows* sizeof(double*));
	}
	for (int i = 0; i < srcRows; i++)
	{
		for (int j = 0; j < srcCols; j++)
		{
			(*dst)[j][i] = src[i][j];
		}

	}
	return *dst;
}


double** matrixInverse(double*** dst, double** src, int srcRows, int srcCols) {

	if (srcRows != srcCols)
	{
		printf("wrong invers");
		exit(1);
	}
	double** dstAug;
	*dst = malloc(srcRows * sizeof(double*));
	dstAug = malloc(srcRows * sizeof(double*));
	for (int i = 0; i < srcRows; i++)
	{
	    (*dst)[i] = malloc(srcCols * sizeof(double));
	    dstAug[i] = malloc(srcCols *2* sizeof(double));
	}

	for (int i = 0; i < srcRows; i++)
	{
		for (int j = 0; j < srcCols * 2; j++)
		{
			if (j < srcCols)
			{
				dstAug[i][j] = src[i][j];
			}
			else if (i + srcCols == j)
			{
				dstAug[i][j] = 1;
			}
			else
			{
				dstAug[i][j] = 0;
			}
		}
	}
	
	divideRow((double*)(dstAug[0]),dstAug[0][0], srcCols*2);
	
	for (int i = 0; i < srcRows; i++)
	{
		for (int j = 0; j < i; j++)
		{
			if (dstAug[i][j] != 0) {
				if (dstAug[j][j] == 0)
				{
					printf("Error,0 in matrix");
					exit(1);
				}
				susubtractNRowb((double*)(dstAug[i]), (double*)(dstAug[j]), dstAug[i][j] / dstAug[j][j], srcCols * 2);
			}
		}
		divideRow((double*)(dstAug[i]), dstAug[i][i], srcCols * 2);
	}


	for (int i = srcRows-1; i>=0; i--)
	{
		for (int j = srcCols-1; j>i ; j--)
		{
			if (dstAug[i][j] != 0) {
				if (dstAug[j][j] == 0)
				{
					printf("Error,0 in matrix");
					exit(1);
				}
				susubtractNRowb((double*)(dstAug[i]), (double*)(dstAug[j]), dstAug[i][j] / dstAug[j][j], srcCols * 2);
			}
		}
		divideRow((double*)(dstAug[i]), dstAug[i][i], srcCols * 2);
	}
	for(int i=0;i<srcRows;i++){
	  for(int j=0;j<srcCols;j++){
	    (*dst)[i][j] =dstAug[i][j+srcCols];
	  }
	}
	for (int i=0;i<srcRows;i++){
	  free(dstAug[i]);
	}
	free(dstAug);
	return *dst;
}

double* divideRow(double* row, double divisor, int rowCols) {
		for (int i = 0; i < rowCols; i++)
		{
			row[i] = row[i] / divisor;
		}
		return row;
}

double* susubtractNRowb(double* row, double* substractorMulRow, double multipler, int rowCols) {
		for (int i = 0; i < rowCols; i++)
		{
			row[i] = row[i] - multipler * substractorMulRow[i];
		}
		return row;
}

double** addCols(double*** dst,double** src, int srcRow,int srcCols) {
                *dst= malloc(srcRow * sizeof(double*));
		
		for (int i = 0; i <srcRow; i++)
		{
		  (*dst)[i] = malloc((srcCols+1)* sizeof(double));
		}

		for (int i = 0; i < srcRow; i++)
		{
			for (int j = 0; j < srcCols+1; j++)
			{
				if (j==0)
				{
					(*dst)[i][0] = 1;
				}
				else {
					(*dst)[i][j] = src[i][j-1];
				}
				
			}
		}


		return *dst;



}
