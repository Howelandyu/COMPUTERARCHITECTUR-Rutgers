#include<stdlib.h>
#include<stdio.h>
#include<stdbool.h>

bool isPrime(int number) {
  if(number<2){
            return false;
	}
	int reminder;
	int i=2;
	while( i < number)
	{
		reminder = number % i;
		if(reminder == 0)
		{
			return false;
		}
		i++;
	}
	return true;
}

bool isRightTruncatablePrime(int number) {
	while (number>0)
	{
		
		if (!isPrime(number))
		{
			return false;
		}
		number /= 10;
	}
	return true;
}



int main(int argc, char** argv) {
	
	if (argc<2)
	{
		printf("the error command");
		exit(0);
	}
	FILE* fp = fopen(argv[1], "r");
	if (fp==NULL)
	{
		printf("No file here");
		exit(0);
	}
	int num=0;
	int value;
	fscanf(fp,"%d\n",&num);
	for(int i=0;i<num;i++){
	   fscanf(fp,"%d\n",&value);
	   if(isRightTruncatablePrime(value)){
	     printf("yes\n");
	   }
	   else{
	       printf("no\n");
	   }
	}
	return 0;
}
