
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

bool isMagic(int* arr, int n) {
        int sum;
	int i=0;
	int j=0;
	while ( i < n)
	{
		sum = 0;
		while ( j < n)
		{
			sum += *(arr + i * n + j);
			j++;
		}
		if (sum!=15)
		{
			return false;

		}
		
		sum=0;

		while ( j < n)
		{
			sum += *(arr + j * n + i);
			j++;
		}
		if (sum != 15)
		{
			return false;
		}
		i++;
	}
	return true;
}






int main(int argc, const char * argv[]) {
	int n;
	FILE* fp=fopen(argv[1],"r");
	fscanf(fp,"%d\n", &n);
	int* arr = malloc(n * n * sizeof(int));
	//int read;
	int i=0;
	while ( i < n*n)
	{
	        fscanf(fp,"%d", arr + 1);
		i++;

	}
	if (isMagic(arr,n)==1)
	  {
		printf("magic\n");

	}
	else
	{
		printf("not-magic\n");
	}
}
