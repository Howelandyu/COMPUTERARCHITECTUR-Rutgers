#include<stdlib.h>
#include<stdio.h>
#include<stdbool.h>

typedef struct Nodes {
	int number;
	struct Nodes* left;
	struct Nodes* right;
}Node;

int TreeDeep(Node* tree)
{
	int deep = 0;
	if (tree != NULL)
	{
		int leftdeep = TreeDeep(tree->left);
		int rightdeep = TreeDeep(tree->right);
		deep = leftdeep >= rightdeep ? leftdeep + 1 : rightdeep + 1;
	}

	return deep;
}

bool insertNode(Node* tree, int number) {
         Node* temp = malloc(sizeof(Node));
	if (temp == NULL)
	{
		temp->number = number;
		return true;
	}
	else
	{
		if (number <= temp->number)
		{
			temp->left = tree;
		}
		else
		{
			temp->right = tree;
		}

	}
}

bool deleteNode(Node* tree, int number) {
        Node* temp=tree;
	if (temp == NULL)
	{
		return;
	}

	else
	{
		if (number < temp->number)
		{
			deleteNode(tree->left, number);
		}
		else if(number > temp->number)
		{
			deleteNode(tree->right, number);
		}
		else
		{
			
		}

	}

}

bool searchNode(Node* tree, int number) {
	if (tree == NULL)
	{
		return;
	}
	if (tree->number = number)
	{
		return true;
	}
	else
	{
		if (number <= tree->number)
		{
			searchNode(tree->left, number);
		}
		else
		{
			searchNode(tree->right, number);
		}
	}
}

int main(int argc, char** argv) {
	if (argc < 2)
	{
		printf("error\n");
		exit(0);

	}
	FILE* fp = fopen(argv[1], "r");
	if (fp == NULL)
	{
		printf("error\n");
		exit(0);
	}

	struct Node* root = NULL;

	char operation;
	int number;
	while (fscanf(fp, "%c %d\n", &operation, &number) != EOF)
	{
		printf("%c %d\n", operation, number);
		if (operation == 'i')
		{
			insertNode(root, number);
			printf("insert\t%d", TreeDeep(root));
		}
		else if (operation == 's')
		{
			searchNode(root, number);
			printf("present%d", TreeDeep(root));
		}
		else if (operation == 'd')
		{
			deleteNode(root, number);
			printf("success");
		}
	}


	return 0;
}
