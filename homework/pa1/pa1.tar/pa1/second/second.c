#include<stdlib.h>
#include<stdio.h>
#include<stdbool.h>
 
typedef struct Nodes {
	int number;
	struct Nodes* next;
}Node;

typedef Node* Linkedlist;

void printNode(Linkedlist list) {
	Node* temp = list;
	int num = 0;
	while (temp)
	{
		num++;
		temp = temp->next;
	}
	printf("%d\n", num);

	Node* head = list;
	while (head)
	{
		printf("%d", head->number);
		if (head->next)
		{
			printf(" ");
		}
		else
		{
			printf("\n");
		}
		head = head->next;
	}

}

void insertNode(int number, Linkedlist list){
  Node* temp = malloc(sizeof(Node));
	temp->number = number;
	Node* head = list;
        Node* previous=malloc(sizeof(Node));
	//Node* after=malloc(sizeof(Node));
	Node* previousNode=malloc(sizeof(Node));
	bool appeared;
	while(head){
	  if(head->number==temp->number){
	    appeared=true;
	    break;
	  }
	  else{
	    if(temp->number>previous->number&&temp->number<head->number){
	      previous=previousNode;
	      //after=head;
	      break;
	    }
	    else{
	      if(temp->number<head->number){
		previous=NULL;
		//after=head;
		break;
	      }
	    }
	  }
	}
	previousNode=head;
	head=head->next;
	if(appeared==true){
	  return;
	}
}

void deleteNode(int number, Linkedlist list) {
	Node* preNode = NULL;
	Node* DelNode = list;
	while (DelNode)
	{
		if (DelNode->number==number)
		{
			if (preNode!=NULL)
			{
				preNode->next = DelNode->next;
				DelNode = NULL;
			}
			else
			{
				list = list->next;
				DelNode = NULL;
			}
			return;
		}
		else
		{
			preNode = DelNode;
			DelNode = DelNode->next;
		}
	}
}

void free_list(Linkedlist head) {
        Node* temp = head;
	while (temp!=NULL)
	{
	        Node* temp2 = temp;
		temp = temp->next;
		free(temp2);
	}
}

int main(int argc, char** argv) {
	if (argc<2)
	{
		printf("error\n");
		exit(0);

	}
	FILE* fp = fopen(argv[1], "r");
	if (fp==NULL)
	{
		printf("error\n");
		exit(0);
	}

	Linkedlist list = NULL;

	char operation;
	int number;
	while (fscanf(fp,"%c %d\n", &operation, &number)!=EOF)
	{
		if (operation=='i')
		{
			insertNode(number, list);
		}
		else if (operation=='d')
		{
			deleteNode(number, list);
		}
	}
	printNode(list);

	return 0;
}
