#include<stdlib.h>
#include<stdio.h>
#include<stdbool.h>
#define BUCKET_SIZE 1000


 typedef struct Node {
	int key;
	struct Node* next;
 }Node;
 typedef Node* HashTable;


 int hash(int key) {
	int value = key % BUCKET_SIZE;
	if (value<0)
	{
		value += BUCKET_SIZE;
	}
	return value;
 } 

 bool mySearchH(HashTable* hashTable,int number) {
	int index=hash(number);
	Node* head =(*(hashTable + index));
	while (head)
	{
		if (head->key==number)
		{
			return true;
		}
		head = head->next;
	}
	return false;

 }

 bool insertNum(HashTable* hashTable, int number) {
        if (mySearchH(hashTable, number))
        {
		return false;
	}
	Node* insertNode=(Node*)malloc(sizeof(Node));
		insertNode->key=number;
		insertNode->next=NULL;
		int index=hash(number);
		Node* head=*(hashTable+index);
		while (head->next!=NULL)
		{
			head = head->next;
		}
	head->next = insertNode;
	return true;
} 



 int main(int argc, char** argv) {
	Node** hashTable = (Node** )malloc(BUCKET_SIZE * sizeof(Node*));
	if (argc < 2)
	{
		printf("error\n");
		exit(0);

	}
	FILE* fp = fopen(argv[1], "r");
	if (fp == NULL)
	{
		printf("error\n");
		exit(0);
	}

	char operation;
	int number;
	while (fscanf(fp,"%c\t%d", &operation, &number) != EOF)
	{
		if (operation == 'i')
		{
		        if (insertNum(hashTable,number)){
				printf("inserted\n");
			}
			else {
				printf("duplicate\n");
			}
		}
		else if (operation == 's')
		{
			if (mySearchH(hashTable, number)) {
				printf("present\n");
			}
			else{
				printf("absent\n");
			}
		}
	}


	return 0;
 }
