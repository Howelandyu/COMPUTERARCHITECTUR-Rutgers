#include<stdlib.h>
#include<stdio.h>
#include<stdbool.h>
#include<string.h>

int main(int argc, char** argv) {
	if (argc < 2)
	{
		printf("error\n");
		exit(0);

	}
	int i=0;
	while ( i < argc)
	{
		printf("%c", argv[i][strlen(argv[i]) - 1]);
		i++;

	}
	return 0;
}
