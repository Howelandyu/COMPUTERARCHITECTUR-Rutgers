#include<stdlib.h>
#include<stdio.h>
#include<stdbool.h>


bool isVowel(char* letter){
  if(letter=='a'||'e'||'i'||'o'||'u'){
    return true;
  }
  else{
    return false;
  }
}

int main(int argc, char** argv) {
	if (argc < 2)
	{
		printf("error\n");
		exit(0);

	}
	
	
	for(int i=0;i<argv;i++)
	{
		if(isVowel(argv[i])) {
			printf("%syay", argv[i]);

		}
		else
		{
			while (i<strlen(argv[i]))
			{
				if (isVowel(*(argv + i))) {
				  strcpy(i, strlen(argv[i]));
				  strcpy(0, i - 1);
				}
				i++;
			}
			char* first;
			char* second;
				printf("%s%say", second, first);
		}
	}
	return 0;
}
