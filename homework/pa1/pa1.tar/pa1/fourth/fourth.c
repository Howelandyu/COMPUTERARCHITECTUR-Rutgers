
#include <stdio.h>
#include <stdlib.h>
#include<stdbool.h>

int getIndex(int row, int col, int maxRows, int maxCols) {
    return row * maxRows + col;
}

int getRow(int row) {
    return row;
}
int getCol(int col){
    return col;
}

int main(int argc, const char * argv[]) {
    if (argc<2)
    {
        printf("error\n");
        exit(0);
        
    }
    
    int matrix1Row, matrix1Cols;
    int matrix2Row, matrix2Cols;
    
    FILE* fp=fopen(argv[1],"r");
    if(fp==NULL){
      printf("error\n");
      exit(0);
    }
        fscanf(fp,"%d %d", &matrix1Row, &matrix1Cols);
	int* matrixA = malloc(matrix1Row * matrix1Cols * sizeof(int));
	int i=0;
	int j=0;
	int k=0;
	while ( i < matrix1Row*matrix1Cols)
	{
		fscanf(fp, "%d", matrixA + i);
		i++;
	}


	fscanf(fp, "%d %d", &matrix2Row, &matrix2Cols);
	int* matrixB = malloc(matrix2Row * matrix2Cols * sizeof(int));

	while ( i < matrix2Row * matrix2Cols)
	{
	        fscanf(fp,"%d", matrixB + i);
		i++;
	}

	int* matrixC=(int*)malloc((matrix1Row*matrix2Cols)*sizeof(int));
	
	while (i < matrix1Row)
	{
		while ( j < matrix2Cols)
		{
			int sum = 0;
		        while( k < matrix2Cols)
			{
				int indexA = getIndex(i, k, matrix1Row, matrix1Cols);
				int indexB = getIndex(k, j, matrix2Row, matrix2Cols);
				int multiply = (*(matrixA + indexA)) * (*(matrixB + indexB));
				sum += multiply;
				k++;
			}
			int indexC = getIndex(i, j, matrix1Row, matrix2Cols);
			*(matrixC+indexC) = sum;
			j++;
		}
		i++;
	}

	i=0;
	while(i<matrix1Row){
	  j=0;
	  while(j<matrix2Cols){
	    printf("%d ",*(matrixC+i*matrix1Row+j));
	    j++;
	  }
	printf("\n");
	i++;
	}

    return 0;
}
